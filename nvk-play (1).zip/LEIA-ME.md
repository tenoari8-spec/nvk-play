# NVK PLAY — pacote do app (Etapas 1 a 10)

## Arquivos
- `index.html`, `app.js` — o aplicativo
- `config.js` — **você edita**: dados do Supabase e contato
- `manifest.json`, `sw.js`, `icon-*.png` — instalação como app (PWA)
- `supabase/schema.sql` — banco de dados e regras de segurança

## Passo a passo
1. Crie um projeto grátis em supabase.com.
2. SQL Editor > New query: cole todo o `supabase/schema.sql` e toque em Run. Pode rodar de novo sem problema.
3. Project Settings > API: copie "Project URL" e a chave **anon public** para o `config.js`.
   Nunca use a chave "service_role". Preencha também `contact` (aparece na Política de privacidade e nos Termos).
4. Authentication > Providers > Email: para testar rápido, desligue "Confirm email" (opcional).
5. Hospede esta pasta (Netlify, Cloudflare Pages ou GitHub Pages) e abra o endereço no Chrome do celular.
6. No app, toque em "Criar conta".
7. Volte ao SQL Editor e rode a última linha do schema.sql (a comentada), com o seu e-mail, para virar administrador:
   `insert into public.admins (user_id) select id from auth.users where email = 'SEU@EMAIL.COM';`
8. Entre de novo no app: em Perfil aparece o **Painel administrativo**.

## Vídeos
Links aceitos no cadastro: `.mp4`, `.webm`, `.m3u8` (HLS) ou o link de um vídeo do YouTube, Google Drive (público) ou Odysee (link de incorporação).
Vídeos incorporados usam o player do próprio serviço (sem progresso salvo, ±10s ou próximo episódio automático).

## Textos legais
Os textos de Política de privacidade e Termos de uso são um modelo simples. Revise antes de publicar para outras pessoas.
