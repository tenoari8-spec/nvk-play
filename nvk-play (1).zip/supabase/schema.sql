-- NVK PLAY — Etapa 8: banco de dados (rode no Supabase: SQL Editor > New query > Run)
-- Guarda só metadados (textos e links). Os vídeos ficam em outro lugar; aqui entram apenas as URLs.

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create or replace function public.is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.admins where user_id = auth.uid())
$$;

create table if not exists public.profiles (
  id text primary key check (char_length(id) between 2 and 40),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 20),
  avatar int not null default 0 check (avatar between 0 and 7),
  kids boolean not null default false,
  rating text not null default '12' check (rating in ('L','10','12','14','16','18')),
  created_at timestamptz not null default now()
);
create index if not exists profiles_user_idx on public.profiles(user_id);

-- máximo de 5 perfis por conta (ignora o próprio perfil ao editar)
create or replace function public.limit_profiles() returns trigger language plpgsql as $$
begin
  if (select count(*) from public.profiles where user_id = new.user_id and id <> new.id) >= 5 then
    raise exception 'Limite de 5 perfis por conta';
  end if;
  return new;
end $$;
drop trigger if exists trg_limit_profiles on public.profiles;
create trigger trg_limit_profiles before insert on public.profiles
  for each row execute function public.limit_profiles();

create table if not exists public.favorites (
  profile_id text not null references public.profiles(id) on delete cascade,
  content_id text not null,
  added_at timestamptz not null default now(),
  primary key (profile_id, content_id)
);

create table if not exists public.progress (
  profile_id text not null references public.profiles(id) on delete cascade,
  prog_key text not null,
  pos double precision not null default 0,
  dur double precision not null default 0,
  at_ms bigint not null,
  done boolean not null default false,
  primary key (profile_id, prog_key)
);

create table if not exists public.user_settings (
  user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  ask boolean not null default true,
  auto_next boolean not null default true,
  last_profile text
);

create table if not exists public.contents (
  id text primary key,
  title text not null check (char_length(title) between 2 and 120),
  description text not null default '' check (char_length(description) <= 300),
  type text not null check (type in ('filme','serie','novela','desenho','programa','documentario','especial')),
  genre text not null default '',
  year int check (year between 1900 and 2100),
  country text not null default '',
  duration text not null default '',
  cast_list text not null default '',
  director text not null default '',
  rating text not null default 'L' check (rating in ('L','10','12','14','16','18')),
  cover text not null default '' check (cover = '' or cover ~* '^https?://'),
  banner text not null default '' check (banner = '' or banner ~* '^https?://'),
  video text not null default '' check (video = '' or video ~* '^https?://'),
  subs text not null default '' check (subs = '' or subs ~* '^https?://'),
  featured boolean not null default false,
  added_at_ms bigint not null default (extract(epoch from now()) * 1000)::bigint
);

create table if not exists public.episodes (
  id text primary key,
  content_id text not null references public.contents(id) on delete cascade,
  season int not null check (season >= 1),
  num int not null check (num >= 1),
  title text not null check (char_length(title) between 2 and 120),
  description text not null default '' check (char_length(description) <= 300),
  thumb text not null default '' check (thumb = '' or thumb ~* '^https?://'),
  duration text not null default '',
  video text not null default '' check (video = '' or video ~* '^https?://'),
  subs text not null default '' check (subs = '' or subs ~* '^https?://'),
  unique (content_id, season, num)
);

-- Segurança (RLS): cada pessoa só enxerga e altera os próprios dados.
alter table public.admins enable row level security;
alter table public.profiles enable row level security;
alter table public.favorites enable row level security;
alter table public.progress enable row level security;
alter table public.user_settings enable row level security;
alter table public.contents enable row level security;
alter table public.episodes enable row level security;

drop policy if exists "admins: ver o proprio" on public.admins;
create policy "admins: ver o proprio" on public.admins for select to authenticated using (user_id = auth.uid());

drop policy if exists "perfis proprios" on public.profiles;
create policy "perfis proprios" on public.profiles for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "favoritos proprios" on public.favorites;
create policy "favoritos proprios" on public.favorites for all to authenticated
  using (exists (select 1 from public.profiles p where p.id = profile_id and p.user_id = auth.uid()))
  with check (exists (select 1 from public.profiles p where p.id = profile_id and p.user_id = auth.uid()));

drop policy if exists "progresso proprio" on public.progress;
create policy "progresso proprio" on public.progress for all to authenticated
  using (exists (select 1 from public.profiles p where p.id = profile_id and p.user_id = auth.uid()))
  with check (exists (select 1 from public.profiles p where p.id = profile_id and p.user_id = auth.uid()));

drop policy if exists "configuracoes proprias" on public.user_settings;
create policy "configuracoes proprias" on public.user_settings for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Catálogo: todos os usuários logados leem; só administradores alteram.
drop policy if exists "catalogo: ler" on public.contents;
create policy "catalogo: ler" on public.contents for select to authenticated using (true);
drop policy if exists "catalogo: admin escreve" on public.contents;
create policy "catalogo: admin escreve" on public.contents for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "episodios: ler" on public.episodes;
create policy "episodios: ler" on public.episodes for select to authenticated using (true);
drop policy if exists "episodios: admin escreve" on public.episodes;
create policy "episodios: admin escreve" on public.episodes for all to authenticated
  using (public.is_admin()) with check (public.is_admin());


-- ===== Etapa 9 e 10 (pode rodar de novo sem problema) =====
alter table public.profiles add column if not exists rating_cap text check (rating_cap in ('L','10','12','14','16'));
alter table public.user_settings add column if not exists autoplay boolean not null default true;
alter table public.user_settings add column if not exists saver boolean not null default false;
alter table public.user_settings add column if not exists quality text not null default 'auto' check (quality in ('auto','low','high'));

-- Ordem dos destaques e das categorias na página inicial (só administradores alteram)
create table if not exists public.app_config (
  key text primary key check (key in ('featured_order','row_order')),
  value jsonb not null default '[]'::jsonb check (jsonb_typeof(value) = 'array')
);
alter table public.app_config enable row level security;
drop policy if exists "config: ler" on public.app_config;
create policy "config: ler" on public.app_config for select to authenticated using (true);
drop policy if exists "config: admin escreve" on public.app_config;
create policy "config: admin escreve" on public.app_config for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Excluir a própria conta (usado em Configurações > Conta). Apaga perfis, listas e histórico em cascata.
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public as $$
begin
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- DEPOIS de criar a sua conta no app, torne-se administrador (troque pelo seu e-mail):
-- insert into public.admins (user_id) select id from auth.users where email = 'SEU@EMAIL.COM';
