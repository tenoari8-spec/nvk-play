-- Rode DEPOIS de criar a conta no app com este e-mail (Criar conta).
insert into public.admins (user_id)
select id from auth.users where email = 'tenoari8@gmail.com'
on conflict do nothing;

-- Conferir (deve aparecer 1 linha):
select u.email from public.admins a join auth.users u on u.id = a.user_id;
